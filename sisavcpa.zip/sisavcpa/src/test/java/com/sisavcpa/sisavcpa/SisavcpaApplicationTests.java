package com.sisavcpa.sisavcpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SisavcpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
