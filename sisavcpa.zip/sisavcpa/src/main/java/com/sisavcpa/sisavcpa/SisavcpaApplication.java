package com.sisavcpa.sisavcpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SisavcpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SisavcpaApplication.class, args);
	}

}
